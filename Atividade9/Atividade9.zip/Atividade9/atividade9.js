
function maiorDeTres(a, b, c) {
  return Math.max(a, b, c);
}
function ordemCrescente(a, b, c) {
  return [a, b, c].sort(function (x, y) {
    return x - y;
  });
}

function ehPalindromo(texto) {
  var limpo = texto.toLowerCase().replace(/\s+/g, "");
  var invertido = limpo.split("").reverse().join("");
  return limpo === invertido;
}

function verificaSubconjunto(primeira, segunda) {
  if (
    primeira === undefined ||
    segunda === undefined ||
    primeira.trim() === "" ||
    segunda.trim() === ""
  ) {
    return "erro";
  }
  if (primeira.includes(segunda)) {
    return "é um subconjunto";
  }
  return "não é um subconjunto";
}

function diaDaSemana(dataTexto) {

  var partes = dataTexto.split("-");
  var data = new Date(partes[0], partes[1] - 1, partes[2]);
  var dias = [
    "Domingo",
    "Segunda-feira",
    "Terça-feira",
    "Quarta-feira",
    "Quinta-feira",
    "Sexta-feira",
    "Sábado",
  ];
  return dias[data.getDay()];
}
function mostrar(id, texto) {
  document.getElementById(id).textContent = texto;
}

function executar1() {
  var a = parseFloat(document.getElementById("n1a").value);
  var b = parseFloat(document.getElementById("n1b").value);
  var c = parseFloat(document.getElementById("n1c").value);
  if (isNaN(a) || isNaN(b) || isNaN(c)) {
    return mostrar("r1", "Preencha os três números.");
  }
  mostrar("r1", "O maior é: " + maiorDeTres(a, b, c));
}

function executar2() {
  var a = parseFloat(document.getElementById("n2a").value);
  var b = parseFloat(document.getElementById("n2b").value);
  var c = parseFloat(document.getElementById("n2c").value);
  if (isNaN(a) || isNaN(b) || isNaN(c)) {
    return mostrar("r2", "Preencha os três números.");
  }
  mostrar("r2", "Ordem crescente: " + ordemCrescente(a, b, c).join(", "));
}

function executar3() {
  var texto = document.getElementById("s3").value;
  if (texto.trim() === "") {
    return mostrar("r3", "Digite um texto.");
  }
  var resposta = ehPalindromo(texto) ? "É palíndromo" : "Não é palíndromo";
  mostrar("r3", resposta);
}

function executar4() {
  var p1 = document.getElementById("p1").value;
  var p2 = document.getElementById("p2").value;
  mostrar("r4", verificaSubconjunto(p1, p2));
}

function executar5() {
  var data = document.getElementById("d5").value;
  if (data === "") {
    return mostrar("r5", "Escolha uma data.");
  }
  mostrar("r5", diaDaSemana(data));
}
